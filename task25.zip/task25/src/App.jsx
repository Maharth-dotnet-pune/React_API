import React from "react";
import HomePage from "./pages/HomePage";

function App() {
  return (
    <div>
      <h1>My Product Store</h1>
      <HomePage />
    </div>
  );
}

export default App;
