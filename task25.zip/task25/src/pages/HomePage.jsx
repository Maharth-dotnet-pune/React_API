import React, { useEffect, useState } from "react";
import { fetchProducts } from "../api/booksapi";
import Spinner from "../Components/Spinner";
import ErrorAlert from "../Components/ErrorAlert";
import BookList from "../Components/BookList";

function HomePage() {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    async function loadData() {
      try {
        const data = await fetchProducts();
        setProducts(data);
      } catch (err) {
        setError("Failed to load data. Please try again.");
      } finally {
        setLoading(false);
      }
    }
    loadData();
  }, []);

  if (loading) return <Spinner />;
  if (error) return <ErrorAlert message={error} />;

  return (
    <div>
      <h2>Product List</h2>
      <BookList products={products} />
    </div>
  );
}

export default HomePage;
