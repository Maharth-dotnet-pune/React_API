import "./BookList.css";

function BookList({ products }) {
  return (
    <div className="product-grid">
      {products.map((p) => (
        <div key={p.id} className="product-card">
          <h3>{p.name}</h3>
          
          <p><strong>Price:</strong> {p.price}</p>
          <p><strong>Category:</strong> {p.category}</p>
        </div>
      ))}
    </div>
  );
}

export default BookList;
