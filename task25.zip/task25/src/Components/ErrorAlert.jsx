import "./ErrorAlert.css";

function ErrorAlert({ message }) {
  return (
    <div className="error-alert">
      <p>{message}</p>
    </div>
  );
}

export default ErrorAlert;
